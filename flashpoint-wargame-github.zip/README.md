# Flashpoint Wargame

GitHub-ready multiplayer prototype for **Flashpoint: Pacific War 2027**.

## Run it

Install Node.js LTS, then:

```bash
npm install
npm start
```

Open:

```text
http://localhost:3000
```

## Google Maps API key

`public/index.html` contains the Google Maps script. Replace the placeholder API key with your restricted Google Maps JavaScript API key.

**Do not commit an unrestricted key to GitHub.** Restrict it by website/referrer in Google Cloud.

## Push to GitHub

Create an empty repository on GitHub, then run:

```bash
git init
git add .
git commit -m "Initial Flashpoint wargame"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/flashpoint-wargame.git
git push -u origin main
```

## Important

GitHub Pages only hosts static files. The multiplayer `server.js` requires a Node-compatible server. For production, keep the frontend and authoritative game server separate.

## Planned modules

- Invasion / Supremacy hex maps
- Terrain
- Fog of war
- Moderator authentication
- Full combat rules
- Logistics
- Reserves
- Information warfare
- Intervention events
- Replay
- PostgreSQL persistence
